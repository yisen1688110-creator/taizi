const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronAPI', {
    updateBadge: (count) => ipcRenderer.send('update-badge', count),
    focusWindow: () => ipcRenderer.send('focus-window')
})
